module.exports = {
  istanbulFolder: 'coverage/contracts',
  skipFiles: [
    'mocks/**',
    'echidna/**',
    'tools/**'
  ]
};
