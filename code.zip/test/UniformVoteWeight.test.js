const { expect } = require("chai");
const { ethers } = require("hardhat");
const { deployTempl } = require("./utils/deploy");
const { mintToUsers } = require("./utils/mintAndPurchase");
const { encodeSetJoinPausedDAO } = require("./utils/callDataBuilders");

describe("Uniform vote weight (no priest bonus)", function () {
  let templ;
  let token;
  let owner, priest, member1, member2;
  let accounts;
  const ENTRY_FEE = ethers.parseUnits("100", 18);
  const TOKEN_SUPPLY = ethers.parseUnits("10000", 18);

  beforeEach(async function () {
    ({ templ, token, accounts } = await deployTempl({ entryFee: ENTRY_FEE }));
    [owner, priest, member1, member2] = accounts;

    await mintToUsers(token, [priest, member1, member2], TOKEN_SUPPLY);
  });

  it("returns 1 for members and 0 for non-members", async function () {
    // Priest is auto-enrolled at deployment
    expect(await templ.getVoteWeight(priest.address)).to.equal(1);
    expect(await templ.getVoteWeight(member1.address)).to.equal(0);

    await token.connect(member1).approve(await templ.getAddress(), ENTRY_FEE);
    await templ.connect(member1).join();

    expect(await templ.getVoteWeight(priest.address)).to.equal(1);
    expect(await templ.getVoteWeight(member1.address)).to.equal(1);
    expect(await templ.getVoteWeight(member2.address)).to.equal(0);
  });

  it("counts one vote per member and ties fail", async function () {
    await token.connect(member1).approve(await templ.getAddress(), ENTRY_FEE);
    await templ.connect(member1).join();

    await templ.connect(priest).createProposalSetJoinPaused(
      true,
      7 * 24 * 60 * 60,
      "Pause joins",
      "Tie vote should fail"
    );

    await ethers.provider.send("evm_increaseTime", [10]);
    await ethers.provider.send("evm_mine");

    await templ.connect(priest).vote(0, true);
    await templ.connect(member1).vote(0, false);

    const proposal = await templ.getProposal(0);
    expect(proposal.yesVotes).to.equal(1);
    expect(proposal.noVotes).to.equal(1);
    expect(proposal.passed).to.be.false;
  });
});
