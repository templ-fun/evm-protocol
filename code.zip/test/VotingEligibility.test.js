const { expect } = require("chai");
const { ethers } = require("hardhat");
const { deployTempl } = require("./utils/deploy");
const { mintToUsers, joinMembers } = require("./utils/mintAndPurchase");
const {
    encodeWithdrawTreasuryDAO,
    encodeSetJoinPausedDAO,
} = require("./utils/callDataBuilders");

describe("Voting Eligibility Based on Join Time", function () {
    let templ;
    let token;
    let owner, priest, member1, member2, member3, member4, lateMember;
    let accounts;
    const ENTRY_FEE = ethers.parseUnits("100", 18);
    const TOKEN_SUPPLY = ethers.parseUnits("10000", 18);

    beforeEach(async function () {
        ({ templ, token, accounts } = await deployTempl({ entryFee: ENTRY_FEE }));
        [owner, priest, member1, member2, member3, member4, lateMember] = accounts;

        await mintToUsers(token, [member1, member2, member3, member4, lateMember], TOKEN_SUPPLY);
    });

    describe("Voting Eligibility Rules", function () {
        it("Should allow members who joined before proposal to vote", async function () {
            // Members 1, 2, 3 join
            await token.connect(member1).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member1).join();
            
            await token.connect(member2).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member2).join();
            
            await token.connect(member3).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member3).join();

            // Wait a bit to ensure clear timestamp difference
            await ethers.provider.send("evm_increaseTime", [100]);
            await ethers.provider.send("evm_mine");

            // Member 1 creates proposal
            await templ.connect(member1).createProposalWithdrawTreasury(
                token.target,
                member1.address,
                ethers.parseUnits("10", 18),
                7 * 24 * 60 * 60,
                "Withdraw treasury",
                "Eligibility pre-proposal"
            );

            // Wait to ensure voting happens after proposal creation
            await ethers.provider.send("evm_increaseTime", [10]);
            await ethers.provider.send("evm_mine");

            // All three members should be able to vote
            await expect(templ.connect(member1).vote(0, true))
                .to.emit(templ, "VoteCast");
            
            await expect(templ.connect(member2).vote(0, true))
                .to.emit(templ, "VoteCast");
            
            await expect(templ.connect(member3).vote(0, false))
                .to.emit(templ, "VoteCast");

            // Check votes
            const proposal = await templ.getProposal(0);
            expect(proposal.yesVotes).to.equal(2);
            expect(proposal.noVotes).to.equal(1);
        });

        it("Should prevent members who joined after quorum from voting", async function () {
            // Initial members join (ensure no auto-quorum at creation)
            await token.connect(member1).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member1).join();
            await token.connect(member2).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member2).join();
            await token.connect(member3).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member3).join();
            await token.connect(member4).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member4).join();

            // Create proposal (4 members total; auto-yes alone won't meet quorum)
            await templ.connect(member1).createProposalWithdrawTreasury(
                token.target,
                member1.address,
                ethers.parseUnits("10", 18),
                7 * 24 * 60 * 60,
                "Withdraw treasury",
                "Eligibility post-quorum"
            );

            // Reach quorum with pre-quorum members
            await templ.connect(member2).vote(0, true); // yesVotes = 2 of 4 (>=33%)

            // New member joins AFTER quorum is reached
            await token.connect(lateMember).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(lateMember).join();

            // Late member should NOT be able to vote after quorum
            await expect(templ.connect(lateMember).vote(0, true))
                .to.be.revertedWithCustomError(templ, "JoinedAfterProposal");

            // Pre-quorum members can still vote
            await expect(templ.connect(member3).vote(0, false)).to.emit(templ, "VoteCast");
        });

        it("Should allow members who joined earlier in the quorum block to vote", async function () {
            // Four members join to avoid auto-quorum at creation
            await token.connect(member1).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member1).join();
            await token.connect(member2).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member2).join();
            await token.connect(member3).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member3).join();
            await token.connect(member4).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member4).join();

            await templ.connect(member1).createProposalWithdrawTreasury(
                token.target,
                member1.address,
                ethers.parseUnits("10", 18),
                7 * 24 * 60 * 60,
                "Withdraw treasury",
                "Eligibility same block"
            );

            // Batch the quorum-reaching vote and the late join in the same block
            await token.connect(lateMember).approve(await templ.getAddress(), ENTRY_FEE);
            await ethers.provider.send("evm_setAutomine", [false]);
            try {
                const txOverrides = { gasLimit: 1_000_000 };
                // Submit the join first so it lands before the quorum-reaching vote in the same block.
                const joinTx = await templ.connect(lateMember).join({ ...txOverrides });
                const voteTx = await templ.connect(member2).vote(0, true, txOverrides);

                await ethers.provider.send("evm_mine");
                await Promise.all([joinTx.wait(), voteTx.wait()]);
            } finally {
                await ethers.provider.send("evm_setAutomine", [true]);
            }

            // Late member joined in the quorum block -> allowed to vote post-quorum
            await expect(templ.connect(lateMember).vote(0, true)).to.emit(templ, "VoteCast");
        });

        it("Should block members who joined after proposal creation until quorum is reached", async function () {
            // 4 members join initially (avoid auto-quorum at creation)
            await token.connect(member1).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member1).join();
            await token.connect(member2).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member2).join();
            await token.connect(member3).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member3).join();
            await token.connect(member4).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member4).join();

            expect(await templ.getMemberCount()).to.equal(5);

            // Wait before creating proposal
            await ethers.provider.send("evm_increaseTime", [100]);
            await ethers.provider.send("evm_mine");

            // Create proposal - starts with 4 eligible voters
            await templ.connect(member1).createProposalSetJoinPaused(
                true,
                7 * 24 * 60 * 60,
                "Pause joins",
                "Join after creation"
            );

            // One more member joins after proposal creation
            await token.connect(lateMember).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(lateMember).join();

            // Late member cannot vote before quorum is reached
            await expect(templ.connect(lateMember).vote(0, true))
                .to.be.revertedWithCustomError(templ, "JoinedAfterProposal");

            // Pre-quorum members reach quorum
            await templ.connect(member2).vote(0, true);

            // Late member can vote after quorum since they joined before the quorum transaction
            await expect(templ.connect(lateMember).vote(0, false)).to.emit(templ, "VoteCast");

            const snapshots = await templ.getProposalSnapshots(0);
            expect(snapshots.eligibleVotersPreQuorum).to.equal(5n);
            expect(snapshots.eligibleVotersPostQuorum).to.equal(5n);
        });

        it("Keeps the quorum denominator fixed even if membership grows before quorum", async function () {
            await token.connect(member1).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member1).join();
            await token.connect(member2).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member2).join();
            await token.connect(member3).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member3).join();

            await templ.connect(member1).createProposalSetJoinPaused(
                true,
                7 * 24 * 60 * 60,
                "Freeze joins",
                "Quorum denominator snapshot"
            );

            await mintToUsers(token, [owner], TOKEN_SUPPLY);
            for (const joiner of [owner, member4, lateMember]) {
                await token.connect(joiner).approve(await templ.getAddress(), ENTRY_FEE);
                await templ.connect(joiner).join();
            }

            await templ.connect(member2).vote(0, true);

            const snapshots = await templ.getProposalSnapshots(0);
            expect(snapshots.eligibleVotersPreQuorum).to.equal(4n);
            expect(snapshots.eligibleVotersPostQuorum).to.equal(4n);

            const delay = Number(await templ.postQuorumVotingPeriod());
            await ethers.provider.send("evm_increaseTime", [delay + 1]);
            await ethers.provider.send("evm_mine");

            await templ.executeProposal(0);
            expect(await templ.joinPaused()).to.equal(true);
        });

        it("Should prevent gaming the system by adding members after quorum", async function () {
            // Start with just 2 members
            await token.connect(member1).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member1).join();
            
            await token.connect(member2).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member2).join();

            // Wait
            await ethers.provider.send("evm_increaseTime", [100]);
            await ethers.provider.send("evm_mine");

            // Create contentious proposal where member2 would vote no
            await templ.connect(member1).createProposalWithdrawTreasury(
                token.target,
                member1.address,
                ethers.parseUnits("50", 18),
                7 * 24 * 60 * 60,
                "Withdraw treasury",
                "Prevent gaming"
            );

            // Reach quorum immediately with the two existing members
            await templ.connect(member1).vote(0, true);
            // yesVotes = 2 of 2 (auto-yes + member1), quorum reached; add friendly members
            await token.connect(member3).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member3).join();
            await token.connect(member4).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member4).join();

            // New members cannot vote post-quorum
            await expect(templ.connect(member3).vote(0, true))
                .to.be.revertedWithCustomError(templ, "JoinedAfterProposal");
            await expect(templ.connect(member4).vote(0, true))
                .to.be.revertedWithCustomError(templ, "JoinedAfterProposal");

            // Member2 can still vote (pre-quorum)
            await templ.connect(member2).vote(0, false);

            // Another pre-quorum member (the auto-enrolled priest) can also reject it
            await templ.connect(priest).vote(0, false);

            // Result: 1 yes, 2 no - only pre-quorum votes counted so proposal fails
            const proposal = await templ.getProposal(0);
            expect(proposal.yesVotes).to.equal(1);
            expect(proposal.noVotes).to.equal(2);

            // Fast forward to end
            await ethers.provider.send("evm_increaseTime", [7 * 24 * 60 * 60]);
            await ethers.provider.send("evm_mine");

            // Proposal should fail execution (not pass with yes <= no)
            await expect(templ.executeProposal(0))
                .to.be.revertedWithCustomError(templ, "ProposalNotPassed");
        });

        it("Members who join after proposal creation in the same block cannot vote", async function () {
            this.timeout(120000);

            // Member 1 joins so they can open a proposal
            await token.connect(member1).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member1).join();

            await token.connect(lateMember).approve(await templ.getAddress(), ENTRY_FEE);

            const createTx = await templ.connect(member1).createProposalSetJoinPaused(
                true,
                7 * 24 * 60 * 60,
                "Pause joins",
                "Same-block join"
            );
            await createTx.wait();

            const joinTx = await templ.connect(lateMember).join();
            await joinTx.wait();

            await expect(templ.connect(lateMember).vote(0, true))
                .to.be.revertedWithCustomError(templ, "JoinedAfterProposal");

            const joinSequences = await templ.getProposalJoinSequences(0);
            expect(joinSequences.preQuorumJoinSequence).to.equal(2n);
            expect(joinSequences.quorumJoinSequence).to.equal(joinSequences.preQuorumJoinSequence);
        });

        it("Should handle multiple proposals with changing membership correctly", async function () {
            // Initial 2 members
            await token.connect(member1).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member1).join();
            
            await token.connect(member2).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member2).join();

            // Wait
            await ethers.provider.send("evm_increaseTime", [100]);
            await ethers.provider.send("evm_mine");

            // First proposal - 2 eligible voters
            await templ.connect(member1).createProposal(
                "Proposal 1",
                "With 2 members",
                encodeSetJoinPausedDAO(true),
                7 * 24 * 60 * 60
            );

            // Member 3 joins
            await token.connect(member3).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member3).join();

            // Wait for first proposal to end
            await ethers.provider.send("evm_increaseTime", [8 * 24 * 60 * 60]);
            await ethers.provider.send("evm_mine");

            // Second proposal - priest plus 3 existing members eligible
            await templ.connect(member2).createProposal(
                "Proposal 2",
                "With 3 members",
                encodeSetJoinPausedDAO(false),
                7 * 24 * 60 * 60
            );

            // Reach quorum before the new member joins
            await templ.connect(member1).vote(1, true);
            await templ.connect(member2).vote(1, true);

            // Member 4 joins after quorum has been reached
            await token.connect(member4).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member4).join();

            // Wait a bit
            await ethers.provider.send("evm_increaseTime", [100]);
            await ethers.provider.send("evm_mine");

            await templ.connect(member3).vote(1, false);

            await expect(templ.connect(member4).vote(1, true))
                .to.be.revertedWithCustomError(templ, "JoinedAfterProposal");

            const proposal2 = await templ.getProposal(1);
            expect(proposal2.yesVotes).to.equal(2);
            expect(proposal2.noVotes).to.equal(1);
        });
    });

    describe("Edge Cases", function () {
        it("Should handle proposals created in the same block as membership", async function () {
            // Member 1 joins first
            await token.connect(member1).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member1).join();

            // In a real scenario, these would be in the same block, but we can't
            // perfectly simulate that in tests. The contract should handle it correctly
            // by using < instead of <= for timestamp comparison
            
            await token.connect(member2).approve(await templ.getAddress(), ENTRY_FEE);
            await templ.connect(member2).join();
            
            // Create proposal immediately
            await templ.connect(member1).createProposal(
                "Quick Proposal",
                "Same block test",
                encodeSetJoinPausedDAO(true),
                7 * 24 * 60 * 60
            );

            // member2 joined before the proposal, so should be able to vote
            await ethers.provider.send("evm_increaseTime", [100]);
            await ethers.provider.send("evm_mine");
            
            await expect(templ.connect(member2).vote(0, true))
                .to.emit(templ, "VoteCast");
        });

        // Note: A same-block ordering test can be flaky across engines; the
        // "join after creation (not necessarily same block) cannot vote before quorum" case
        // is validated elsewhere in this suite.
    });
});
